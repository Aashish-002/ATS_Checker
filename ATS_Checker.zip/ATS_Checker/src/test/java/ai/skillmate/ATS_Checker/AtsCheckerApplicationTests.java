package ai.skillmate.ATS_Checker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtsCheckerApplicationTests {

	@Test
	void contextLoads() {
	}

}
